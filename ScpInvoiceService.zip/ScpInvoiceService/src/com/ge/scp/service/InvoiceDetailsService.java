package com.ge.scp.service;


import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.ge.scp.util.InvoiceUtility;


@Path("InvoiceDetailsService")
public class InvoiceDetailsService {
	final static Logger logger = Logger.getLogger(InvoiceDetailsService.class);

	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getScpInvoiceDetails(){
		
		System.out.println("in Response....");
		String vendorGsl=null;
		String invoiceNumber=null;
		String poNumber=null;
		Date invoiceDate=null;
		double amount=0.0;
		
		return Response.ok(InvoiceUtility.getData(vendorGsl, invoiceNumber, poNumber, invoiceDate, amount)).build();
	}
	

}
