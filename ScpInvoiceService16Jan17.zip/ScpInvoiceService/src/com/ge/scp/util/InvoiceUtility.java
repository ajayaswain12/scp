package com.ge.scp.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.ge.scp.db.DBConnection;
import com.ge.scp.dto.InvoiceDto;

public class InvoiceUtility {
	
	final static Logger logger = Logger.getLogger(InvoiceUtility.class);
			
	public static List<InvoiceDto> getData(String vendorGsl, String invoiceNumber, String poNumber, Date invoiceDate, double amount){
		List<InvoiceDto> data = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		//String sqlQuery = "select * from V_INV_DETAIL_TEST WHERE ROWNUM <=1000 ORDER BY INVOICE_NO" ;
		//String sqlQuery = "select INVOICE_NO, ACTUAL_INVOICE_DT, INVOICE_CURRENCY_CD, INVOICED_AMOUNT_USD, HOLD_LKP_DESC, PAID_STATUS, " +
		//		"PAYMENT_DUE_DT, PO_NO, VENDOR_GSL, VENDOR_NAME from MV_SCXVIEW_GO_GDW_INV WHERE VENDOR_GSL='596012' AND PO_NO IN ('300080425','805002226')";
		
		/*String condition_vendorGsl;
		String condition_invoiceNumber;
		String condition_poNumber;
		String condition_invoiceDate;
		String condition_amount;
		

		
		if (null != vendorGsl && "" != vendorGsl) {
			condition_vendorGsl = "VENDOR_GSL="+vendorGsl;
		}
		if (null != invoiceNumber && "" != invoiceNumber) {
			condition_invoiceNumber = "INVOICE_NO="+invoiceNumber;
		}
		if (null != poNumber && "" != poNumber) {
			condition_poNumber = "PO_NO="+poNumber;
		}
		if (null != invoiceDate) {
			condition_invoiceDate = "ACTUAL_INVOICE_DT="+invoiceDate;
		}
		if (0.0 != amount) {
			condition_amount = "INVOICED_AMOUNT_USD="+amount;
		}*/
		
		String selectQuery = "select INVOICE_NO, ACTUAL_INVOICE_DT, INVOICE_CURRENCY_CD, INVOICED_AMOUNT_USD, HOLD_LKP_DESC, PAID_STATUS, " +
				"PAYMENT_DUE_DT, PO_NO, VENDOR_GSL, VENDOR_NAME from MV_SCXVIEW_GO_GDW_INV WHERE ";
		
		String whereClause = "";
		if(StringUtils.isNotBlank(vendorGsl)){
		    if(whereClause.length() > 0){
		        whereClause += " AND ";
		    }
		    selectQuery += " VENDOR_GSL = " + vendorGsl;
		}
		if(StringUtils.isNotBlank(invoiceNumber)){
		    if(whereClause.length() > 0){
		        whereClause += " AND ";
		    }
		    selectQuery += " INVOICE_NO = " + invoiceNumber;
		}
		if(StringUtils.isNotBlank(poNumber)){
		    if(whereClause.length() > 0){
		        whereClause += " AND ";
		    }
		    selectQuery += " PO_NO = " + poNumber;
		}
		if(null != invoiceDate){
		    if(whereClause.length() > 0){
		        whereClause += " AND ";
		    }
		    selectQuery += " ACTUAL_INVOICE_DT = " + invoiceDate;
		}
		if(0.0 != amount){
		    if(whereClause.length() > 0){
		        whereClause += " AND ";
		    }
		    selectQuery += " INVOICED_AMOUNT_USD = " + amount;
		}
		

		if(conn != null){
			data = new ArrayList<InvoiceDto>();
			try{
				
				System.out.println("selectQuery="+selectQuery);
				
				//pstmt = conn.prepareStatement(sqlQuery);
				pstmt = conn.prepareStatement(selectQuery);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					invoiceDto = new InvoiceDto();
					invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));
					invoiceDto.setPaymentStatus(rs.getString("PAID_STATUS"));
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					invoiceDto.setPoNumber(rs.getString("PO_NO"));
					invoiceDto.setVendorGsl(rs.getString("VENDOR_GSL"));
					invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));						
					
					data.add(invoiceDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("data="+data);
		return data;
	}
	
	public static List<InvoiceDto> getDataTest(String vendorGsl, String invoiceNumber, String poNumber, Date invoiceDate, double amount){
		List<InvoiceDto> data = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		//String sqlQuery = "select * from V_INV_DETAIL_TEST WHERE ROWNUM <=1000 ORDER BY INVOICE_NO" ;
		String sqlQuery = "select INVOICE_NO, ACTUAL_INVOICE_DT, INVOICE_CURRENCY_CD, INVOICED_AMOUNT_USD, HOLD_LKP_DESC, PAID_STATUS, " +
				"PAYMENT_DUE_DT, PO_NO, VENDOR_GSL, VENDOR_NAME from MV_SCXVIEW_GO_GDW_INV WHERE VENDOR_GSL='596012' AND PO_NO IN ('300080425','805002226')";
		

		if(conn != null){
			data = new ArrayList<InvoiceDto>();
			try{
				
				System.out.println("sqlQuery="+sqlQuery);
				pstmt = conn.prepareStatement(sqlQuery);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					invoiceDto = new InvoiceDto();
					invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));
					invoiceDto.setPaymentStatus(rs.getString("PAID_STATUS"));
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					invoiceDto.setPoNumber(rs.getString("PO_NO"));
					invoiceDto.setVendorGsl(rs.getString("VENDOR_GSL"));
					invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));						
					
					data.add(invoiceDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("data="+data);
		return data;
	}
}
