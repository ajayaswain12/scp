package com.ge.scp.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.ge.scp.util.InvoiceUtility;


@Path("/invoiceDetailsService")
public class InvoiceDetailsService {
	final static Logger logger = Logger.getLogger(InvoiceDetailsService.class);

	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails6")
	public Response getScpInvoiceDetails6(
				@QueryParam(value="vendorGsl") String vendorGsl,
				@QueryParam(value="invoiceNumber") String invoiceNumber,
				@QueryParam(value="poNumber") String poNumber,
				@QueryParam(value="invoiceDate") String invoiceDate,
				@QueryParam(value="amount") double amount){
		
		System.out.println("in Response....getScpInvoiceDetails6:");
		
		System.out.println("vendorGsl="+vendorGsl);
		System.out.println("invoiceNumber="+invoiceNumber);
		System.out.println("poNumber="+poNumber);
		System.out.println("invoiceDate="+invoiceDate);
		System.out.println("amount="+amount);
		
		String uiInvoiceDtPattern = "MM/dd/yyyy";	//Ex: 10/28/2016
		SimpleDateFormat uiInvoiceDateFmt = new SimpleDateFormat(uiInvoiceDtPattern);
		String dbInvoiceDtPattern = "dd-MMM-yy";	//Ex: 28-Oct-16
		SimpleDateFormat dbInvoiceDateFmt = new SimpleDateFormat(dbInvoiceDtPattern);
		
		Date invoiceDt = null;
		String dbInvoiceDateStr = null;			

		try {
			if(StringUtils.isNotBlank(invoiceDate)){
				invoiceDt = uiInvoiceDateFmt.parse(invoiceDate);
				System.out.println("invoiceDt="+invoiceDt);
				
				dbInvoiceDateStr = dbInvoiceDateFmt.format(invoiceDt);
				System.out.println("dbInvoiceDateStr="+dbInvoiceDateStr);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return Response.ok(InvoiceUtility.getInvoiceDetails(vendorGsl, invoiceNumber, poNumber, dbInvoiceDateStr, amount)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getPayments")
	public Response getScpPaymentsDetails(
				@QueryParam(value="vendorGsl") String vendorGsl,
				@QueryParam(value="invoiceNumber") String invoiceNumber,
				@QueryParam(value="poNumber") String poNumber,
				@QueryParam(value="paymentDate") String paymentDate,
				@QueryParam(value="invoicePaidAmountUsd") double invoicePaidAmountUsd){
		
		System.out.println("in Response....getScpPaymentsDetails:");
		
		System.out.println("vendorGsl="+vendorGsl);
		System.out.println("invoiceNumber="+invoiceNumber);
		System.out.println("poNumber="+poNumber);
		System.out.println("paymentDate="+paymentDate);
		System.out.println("invoicePaidAmountUsd="+invoicePaidAmountUsd);
		
		String uiPaymentsDtPattern = "MM/dd/yyyy";	//Ex: 10/28/2016
		SimpleDateFormat uiPaymentsDateFmt = new SimpleDateFormat(uiPaymentsDtPattern);
		String dbPaymentsDtPattern = "dd-MMM-yy";	//Ex: 28-Oct-16
		SimpleDateFormat dbPaymentsDateFmt = new SimpleDateFormat(dbPaymentsDtPattern);
		
		Date paymentDt = null;
		String dbPaymentDateStr = null;			

		try {
			if(StringUtils.isNotBlank(paymentDate)){
				paymentDt = uiPaymentsDateFmt.parse(paymentDate);
				System.out.println("paymentDt="+paymentDt);
				
				dbPaymentDateStr = dbPaymentsDateFmt.format(paymentDt);
				System.out.println("dbPaymentDateStr="+dbPaymentDateStr);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return Response.ok(InvoiceUtility.getPaymentsDetails(vendorGsl, invoiceNumber, poNumber, dbPaymentDateStr, invoicePaidAmountUsd)).build();
	}
	
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails")
	public Response getScpInvoiceDetails(){
		
		System.out.println("In Response...getScpInvoiceDetails()...Test...");
		String vendorGsl=null;
		String invoiceNumber=null;
		String poNumber=null;
		Date invoiceDate=null;
		double amount=0.0;
		
		return Response.ok(InvoiceUtility.getDataTest(vendorGsl, invoiceNumber, poNumber, invoiceDate, amount)).build();
	}	
	
	

}
