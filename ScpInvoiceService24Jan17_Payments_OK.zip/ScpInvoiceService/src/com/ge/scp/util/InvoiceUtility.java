package com.ge.scp.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.ge.scp.db.DBConnection;
import com.ge.scp.dto.InvoiceDto;
import com.ge.scp.dto.PaymentsDto;

public class InvoiceUtility {
	
	final static Logger logger = Logger.getLogger(InvoiceUtility.class);
	
	public static List<InvoiceDto> getInvoiceDetails(String vendorGsl, String invoiceNumber, String poNumber, String invoiceDate, double amount){
		System.out.println("Inside getData6...");
		List<InvoiceDto> invoiceDtoList = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String selectQueryInvoice = "select INVOICE_NO, ACTUAL_INVOICE_DT, INVOICE_CURRENCY_CD, INVOICED_AMOUNT_USD, HOLD_LKP_DESC, PAID_STATUS, " +
				"PAYMENT_DUE_DT, PO_NO, VENDOR_GSL, VENDOR_NAME from MV_SCXVIEW_GO_GDW_INV WHERE 1=1";
		
		if(StringUtils.isNotBlank(vendorGsl)){
		    selectQueryInvoice += " AND VENDOR_GSL = '" + vendorGsl + "'";
		}
		if(StringUtils.isNotBlank(invoiceNumber)){
		    selectQueryInvoice += " AND INVOICE_NO = '" + invoiceNumber + "'";
		}
		if(StringUtils.isNotBlank(poNumber)){
		    selectQueryInvoice += " AND PO_NO = '" + poNumber + "'";
		}
		if(StringUtils.isNotBlank(invoiceDate)){
		    selectQueryInvoice += " AND ACTUAL_INVOICE_DT = '" + invoiceDate + "'";
		}
		if(0.0 != amount){
		    selectQueryInvoice += " AND INVOICED_AMOUNT_USD = '" + amount + "'";
		}
		

		if(conn != null){
			invoiceDtoList = new ArrayList<InvoiceDto>();
			try{
				
				System.out.println("selectQueryInvoice="+selectQueryInvoice);
				
				pstmt = conn.prepareStatement(selectQueryInvoice);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					
					invoiceDto = new InvoiceDto();
					
					if(rs.getString("INVOICE_NO")!= null){
						invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));						
					}else{
						invoiceDto.setInvoiceNumber("");
					}
					
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					
					if(rs.getString("INVOICE_CURRENCY_CD")!= null){
						invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
						
					}else{
						invoiceDto.setCurrency("");
					}					
					
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					
					if(rs.getString("HOLD_LKP_DESC") != null){
						invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));						
					}else{
						invoiceDto.setOnHold("");
					}
					
					if(rs.getString("PAID_STATUS")!= null){
						invoiceDto.setStatus(rs.getString("PAID_STATUS"));
						
					}else{
						invoiceDto.setStatus("");
					}
					
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					
					if(rs.getString("PO_NO")!= null){
						invoiceDto.setPoNumber(rs.getString("PO_NO"));
						
					}else{
						invoiceDto.setPoNumber("");
					}
					
					if(rs.getString("VENDOR_GSL")!= null){
						invoiceDto.setVenderGSL(rs.getString("VENDOR_GSL"));
						
					}else{
						invoiceDto.setVenderGSL("");
					}
					
					if(rs.getString("VENDOR_NAME")!= null){
						invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));
						
					}else{
						invoiceDto.setVendorName("");
					}
					
					invoiceDto.setInvoiceType("");
					invoiceDto.setDue("");
					
					invoiceDtoList.add(invoiceDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("invoiceDtoList="+invoiceDtoList);
		return invoiceDtoList;
	}
	
	public static List<PaymentsDto> getPaymentsDetails(String vendorGsl, String invoiceNumber, String poNumber, String paymentDate, double invoicePaidAmountUsd){
		System.out.println("Inside getPaymentsDetails...");
		List<PaymentsDto> paymentDtoList = null;
		PaymentsDto paymentDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String selectQueryPayment = "select * from MV_SCXVIEW_GO_GDW_INV_PMT WHERE 1=1";
		
		if(StringUtils.isNotBlank(vendorGsl)){
		    selectQueryPayment += " AND VENDOR_GSL = '" + vendorGsl + "'";
		}
		if(StringUtils.isNotBlank(invoiceNumber)){
		    selectQueryPayment += " AND INVOICE_NO = '" + invoiceNumber + "'";
		}
		if(StringUtils.isNotBlank(poNumber)){
		    selectQueryPayment += " AND PO_NO = '" + poNumber + "'";
		}
		if(StringUtils.isNotBlank(paymentDate)){
		    selectQueryPayment += " AND PAYMENT_DT = '" + paymentDate + "'";
		}
		if(0.0 != invoicePaidAmountUsd){
		    selectQueryPayment += " AND INVOICE_PAID_AMOUNT_USD = '" + invoicePaidAmountUsd + "'";
		}
		

		if(conn != null){
			paymentDtoList = new ArrayList<PaymentsDto>();
			try{
				
				System.out.println("selectQueryPayment="+selectQueryPayment);
				
				pstmt = conn.prepareStatement(selectQueryPayment);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					
					paymentDto = new PaymentsDto();
					
					if(rs.getString("VENDOR_GSL")!= null){
						paymentDto.setVenderGSL(rs.getString("VENDOR_GSL"));						
					}else{
						paymentDto.setVenderGSL("");
					}
					
					if(rs.getString("INVOICE_NO")!= null){
						paymentDto.setInvoiceNumber(rs.getString("INVOICE_NO"));						
					}else{
						paymentDto.setInvoiceNumber("");
					}
					
					if(rs.getString("PO_NO")!= null){
						paymentDto.setPoNumber(rs.getString("PO_NO"));						
					}else{
						paymentDto.setPoNumber("");
					}
					
					paymentDto.setPaymentDate(rs.getDate("PAYMENT_DT"));
					
					paymentDto.setInvoicePaidAmountUsd(rs.getDouble("INVOICE_PAID_AMOUNT_USD"));
					
					if(rs.getString("SOURCE_NAME")!= null){
						paymentDto.setSourceName(rs.getString("SOURCE_NAME"));						
					}else{
						paymentDto.setSourceName("");
					}
					
					if(rs.getString("ERP_NAME")!= null){
						paymentDto.setErpName(rs.getString("ERP_NAME"));						
					}else{
						paymentDto.setErpName("");
					}
					
					paymentDto.setMdimInvoiceSk(rs.getLong("MDIM_INVOICE_SK"));					
					
					paymentDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));					
					
					if(rs.getString("INVOICE_ID")!= null){
						paymentDto.setInvoiceId(rs.getString("INVOICE_ID"));						
					}else{
						paymentDto.setInvoiceId("");
					}
					
					paymentDto.setPaymentDueDate(rs.getDate("PAYMENT_DUE_DT"));
					
					if(rs.getString("PAYMENT_CURRENCY_CODE")!= null){
						paymentDto.setPaymentCurrencyCode(rs.getString("PAYMENT_CURRENCY_CODE"));						
					}else{
						paymentDto.setPaymentCurrencyCode("");
					}
					
					if(rs.getString("PAYMENT_TERM_CD")!= null){
						paymentDto.setPaymentTermCd(rs.getString("PAYMENT_TERM_CD"));						
					}else{
						paymentDto.setPaymentTermCd("");
					}
					
					paymentDto.setReceivedDate(rs.getDate("RECEIVED_DT"));
					
					paymentDto.setScannedDate(rs.getDate("SCANNED_DT"));
					
					if(rs.getString("REVERSAL_FLAG")!= null){
						paymentDto.setReversalFlag(rs.getString("REVERSAL_FLAG"));						
					}else{
						paymentDto.setReversalFlag("");
					}
					
					paymentDto.setCheckAmt(rs.getDouble("CHECK_AMT"));
					
					paymentDto.setCheckAmtUsd(rs.getDouble("CHECK_AMT_USD"));
					
					if(rs.getString("CHK_ID")!= null){
						paymentDto.setChkId(rs.getString("CHK_ID"));						
					}else{
						paymentDto.setChkId("");
					}
					
					if(rs.getString("CHK_NBR")!= null){
						paymentDto.setChkNbr(rs.getString("CHK_NBR"));						
					}else{
						paymentDto.setChkNbr("");
					}
					
					paymentDto.setElectronicPaymentsFl(rs.getLong("ELECTRONIC_PAYMENTS_FL"));	
					
					if(rs.getString("INT_EXT_FL")!= null){
						paymentDto.setIntExtFl(rs.getString("INT_EXT_FL"));						
					}else{
						paymentDto.setIntExtFl("");
					}
					
					paymentDto.setInvoicedAmountLcy(rs.getDouble("INVOICED_AMOUNT_LCY"));
					
					paymentDto.setInvoicedAmountUsd(rs.getDouble("INVOICED_AMOUNT_USD"));
					
					paymentDto.setInvoiceCreationDt(rs.getDate("INVOICE_CREATION_DT"));
					
					if(rs.getString("INVOICE_CURRENCY_CD")!= null){
						paymentDto.setInvoiceCurrencyCd(rs.getString("INVOICE_CURRENCY_CD"));						
					}else{
						paymentDto.setInvoiceCurrencyCd("");
					}
					
					paymentDto.setInvoicePaidAmountLcy(rs.getDouble("INVOICE_PAID_AMOUNT_LCY"));
					
					if(rs.getString("PAID_STATUS")!= null){
						paymentDto.setPaidStatus(rs.getString("PAID_STATUS"));						
					}else{
						paymentDto.setPaidStatus("");
					}
					
					if(rs.getString("PAYMENT_MODE")!= null){
						paymentDto.setPaymentMode(rs.getString("PAYMENT_MODE"));						
					}else{
						paymentDto.setPaymentMode("");
					}
					
					if(rs.getString("VENDOR_NAME")!= null){
						paymentDto.setVendorName(rs.getString("VENDOR_NAME"));						
					}else{
						paymentDto.setVendorName("");
					}
					
					if(rs.getString("VENDOR_SITE_GSL")!= null){
						paymentDto.setVendorSiteGsl(rs.getString("VENDOR_SITE_GSL"));						
					}else{
						paymentDto.setVendorSiteGsl("");
					}
					
					paymentDto.setMdimSourceSk(rs.getLong("MDIM_SOURCE_SK"));	
					
					if(rs.getString("SOURCE_PARTITION")!= null){
						paymentDto.setSourcePartition(rs.getString("SOURCE_PARTITION"));						
					}else{
						paymentDto.setSourcePartition("");
					}
					
					paymentDto.setErpCreationAge(rs.getInt("ERP_CREATION_AGE"));
					
					paymentDto.setVendorInvoiceAge(rs.getInt("VENDOR_INVOICE_AGE"));
					
					
					paymentDtoList.add(paymentDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("paymentDtoList="+paymentDtoList);
		return paymentDtoList;
	}
	
	public static List<InvoiceDto> getDataTest(String vendorGsl, String invoiceNumber, String poNumber, Date invoiceDate, double amount){
		List<InvoiceDto> data = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sqlQuery = "select INVOICE_NO, ACTUAL_INVOICE_DT, INVOICE_CURRENCY_CD, INVOICED_AMOUNT_USD, HOLD_LKP_DESC, PAID_STATUS, " +
				"PAYMENT_DUE_DT, PO_NO, VENDOR_GSL, VENDOR_NAME from MV_SCXVIEW_GO_GDW_INV WHERE VENDOR_GSL='596012' AND PO_NO IN ('300080425','805002226')";
		

		if(conn != null){
			data = new ArrayList<InvoiceDto>();
			try{
				
				System.out.println("sqlQuery="+sqlQuery);
				pstmt = conn.prepareStatement(sqlQuery);
				
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					invoiceDto = new InvoiceDto();
					invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));
					invoiceDto.setStatus(rs.getString("PAID_STATUS"));
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					invoiceDto.setPoNumber(rs.getString("PO_NO"));
					invoiceDto.setVenderGSL(rs.getString("VENDOR_GSL"));
					invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));						
					
					data.add(invoiceDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("data="+data);
		return data;
	}
}
