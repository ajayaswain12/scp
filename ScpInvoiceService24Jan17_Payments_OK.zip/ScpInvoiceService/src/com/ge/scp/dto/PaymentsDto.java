package com.ge.scp.dto;

import java.util.Date;

public class PaymentsDto {
	
	private String venderGSL;
	private String invoiceNumber;
	private String poNumber;
	private Date paymentDate;
	private double invoicePaidAmountUsd;	
	
	private String sourceName;
	private String erpName;
	private long mdimInvoiceSk;
	private Date invoiceDate;
	private String invoiceId;
	private Date paymentDueDate;
	private String paymentCurrencyCode;
	private String paymentTermCd;
	private Date receivedDate;
	private Date scannedDate;
	private String reversalFlag;
	private double checkAmt;
	private double checkAmtUsd;
	private String chkId;
	private String chkNbr;
	private long electronicPaymentsFl;
	private String intExtFl;
	private double invoicedAmountLcy;
	private double invoicedAmountUsd;
	private Date invoiceCreationDt;
	private String invoiceCurrencyCd;
	private double invoicePaidAmountLcy;	
	private String paidStatus;
	private String paymentMode;	
	private String vendorName;
	private String vendorSiteGsl;
	private long mdimSourceSk;
	private String sourcePartition;
	private int erpCreationAge;
	private int vendorInvoiceAge;
	
	
	public String getVenderGSL() {
		return venderGSL;
	}
	public void setVenderGSL(String venderGSL) {
		this.venderGSL = venderGSL;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public double getInvoicePaidAmountUsd() {
		return invoicePaidAmountUsd;
	}
	public void setInvoicePaidAmountUsd(double invoicePaidAmountUsd) {
		this.invoicePaidAmountUsd = invoicePaidAmountUsd;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getErpName() {
		return erpName;
	}
	public void setErpName(String erpName) {
		this.erpName = erpName;
	}
	public long getMdimInvoiceSk() {
		return mdimInvoiceSk;
	}
	public void setMdimInvoiceSk(long mdimInvoiceSk) {
		this.mdimInvoiceSk = mdimInvoiceSk;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public Date getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(Date paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getPaymentCurrencyCode() {
		return paymentCurrencyCode;
	}
	public void setPaymentCurrencyCode(String paymentCurrencyCode) {
		this.paymentCurrencyCode = paymentCurrencyCode;
	}
	public String getPaymentTermCd() {
		return paymentTermCd;
	}
	public void setPaymentTermCd(String paymentTermCd) {
		this.paymentTermCd = paymentTermCd;
	}
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public Date getScannedDate() {
		return scannedDate;
	}
	public void setScannedDate(Date scannedDate) {
		this.scannedDate = scannedDate;
	}
	public String getReversalFlag() {
		return reversalFlag;
	}
	public void setReversalFlag(String reversalFlag) {
		this.reversalFlag = reversalFlag;
	}
	public double getCheckAmt() {
		return checkAmt;
	}
	public void setCheckAmt(double checkAmt) {
		this.checkAmt = checkAmt;
	}
	public double getCheckAmtUsd() {
		return checkAmtUsd;
	}
	public void setCheckAmtUsd(double checkAmtUsd) {
		this.checkAmtUsd = checkAmtUsd;
	}
	public String getChkId() {
		return chkId;
	}
	public void setChkId(String chkId) {
		this.chkId = chkId;
	}
	public String getChkNbr() {
		return chkNbr;
	}
	public void setChkNbr(String chkNbr) {
		this.chkNbr = chkNbr;
	}
	public long getElectronicPaymentsFl() {
		return electronicPaymentsFl;
	}
	public void setElectronicPaymentsFl(long electronicPaymentsFl) {
		this.electronicPaymentsFl = electronicPaymentsFl;
	}
	public String getIntExtFl() {
		return intExtFl;
	}
	public void setIntExtFl(String intExtFl) {
		this.intExtFl = intExtFl;
	}
	public double getInvoicedAmountLcy() {
		return invoicedAmountLcy;
	}
	public void setInvoicedAmountLcy(double invoicedAmountLcy) {
		this.invoicedAmountLcy = invoicedAmountLcy;
	}
	public double getInvoicedAmountUsd() {
		return invoicedAmountUsd;
	}
	public void setInvoicedAmountUsd(double invoicedAmountUsd) {
		this.invoicedAmountUsd = invoicedAmountUsd;
	}
	public Date getInvoiceCreationDt() {
		return invoiceCreationDt;
	}
	public void setInvoiceCreationDt(Date invoiceCreationDt) {
		this.invoiceCreationDt = invoiceCreationDt;
	}
	public String getInvoiceCurrencyCd() {
		return invoiceCurrencyCd;
	}
	public void setInvoiceCurrencyCd(String invoiceCurrencyCd) {
		this.invoiceCurrencyCd = invoiceCurrencyCd;
	}
	public double getInvoicePaidAmountLcy() {
		return invoicePaidAmountLcy;
	}
	public void setInvoicePaidAmountLcy(double invoicePaidAmountLcy) {
		this.invoicePaidAmountLcy = invoicePaidAmountLcy;
	}
	public String getPaidStatus() {
		return paidStatus;
	}
	public void setPaidStatus(String paidStatus) {
		this.paidStatus = paidStatus;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getVendorSiteGsl() {
		return vendorSiteGsl;
	}
	public void setVendorSiteGsl(String vendorSiteGsl) {
		this.vendorSiteGsl = vendorSiteGsl;
	}
	public long getMdimSourceSk() {
		return mdimSourceSk;
	}
	public void setMdimSourceSk(long mdimSourceSk) {
		this.mdimSourceSk = mdimSourceSk;
	}
	public String getSourcePartition() {
		return sourcePartition;
	}
	public void setSourcePartition(String sourcePartition) {
		this.sourcePartition = sourcePartition;
	}
	public int getErpCreationAge() {
		return erpCreationAge;
	}
	public void setErpCreationAge(int erpCreationAge) {
		this.erpCreationAge = erpCreationAge;
	}
	public int getVendorInvoiceAge() {
		return vendorInvoiceAge;
	}
	public void setVendorInvoiceAge(int vendorInvoiceAge) {
		this.vendorInvoiceAge = vendorInvoiceAge;
	}
	
	
	@Override
	public String toString() {
		return "PaymentsDto [venderGSL=" + venderGSL + ", invoiceNumber="
				+ invoiceNumber + ", poNumber=" + poNumber + ", paymentDate="
				+ paymentDate + ", invoicePaidAmountUsd="
				+ invoicePaidAmountUsd + ", sourceName=" + sourceName
				+ ", erpName=" + erpName + ", mdimInvoiceSk=" + mdimInvoiceSk
				+ ", invoiceDate=" + invoiceDate + ", invoiceId=" + invoiceId
				+ ", paymentDueDate=" + paymentDueDate
				+ ", paymentCurrencyCode=" + paymentCurrencyCode
				+ ", paymentTermCd=" + paymentTermCd + ", receivedDate="
				+ receivedDate + ", scannedDate=" + scannedDate
				+ ", reversalFlag=" + reversalFlag + ", checkAmt=" + checkAmt
				+ ", checkAmtUsd=" + checkAmtUsd + ", chkId=" + chkId
				+ ", chkNbr=" + chkNbr + ", electronicPaymentsFl="
				+ electronicPaymentsFl + ", intExtFl=" + intExtFl
				+ ", invoicedAmountLcy=" + invoicedAmountLcy
				+ ", invoicedAmountUsd=" + invoicedAmountUsd
				+ ", invoiceCreationDt=" + invoiceCreationDt
				+ ", invoiceCurrencyCd=" + invoiceCurrencyCd
				+ ", invoicePaidAmountLcy=" + invoicePaidAmountLcy
				+ ", paidStatus=" + paidStatus + ", paymentMode=" + paymentMode
				+ ", vendorName=" + vendorName + ", vendorSiteGsl="
				+ vendorSiteGsl + ", mdimSourceSk=" + mdimSourceSk
				+ ", sourcePartition=" + sourcePartition + ", erpCreationAge="
				+ erpCreationAge + ", vendorInvoiceAge=" + vendorInvoiceAge
				+ "]";
	}	
		
}
