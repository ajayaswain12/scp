package com.ge.scp.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.ge.scp.dto.InvoiceDto;


public class DBConnection {
	
	final static Logger logger = Logger.getLogger(DBConnection.class);
	private static final ResourceBundle resource = ResourceBundle.getBundle("com.ge.scp.resources.AppDetailsResource");

	static DBConnection dbConnInstance = null;
	Connection connection = null;

	private static String SCP_DB_URL;
	private static String SCP_DB_UID;
	private static String SCP_DB_PWD;
	
	//NEED TO READ CONFIG FILE FROM PATH
	private void loadPropertiesFile(){	
			try{
				SCP_DB_URL = resource.getString("SCP_DB_URL");
				SCP_DB_UID = resource.getString("SCP_DB_UID");
				SCP_DB_PWD = resource.getString("SCP_DB_PWD");				
			}catch(Exception e){
				e.printStackTrace();
		}
	}

	public static DBConnection getInstance(){
		if(dbConnInstance == null){
			dbConnInstance = new DBConnection();
		}
		return dbConnInstance;
	}

	//DBConnection using typical driver connection
	public Connection getDBConnection(){
		loadPropertiesFile();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(SCP_DB_URL, SCP_DB_UID, SCP_DB_PWD);
		}catch(ClassNotFoundException cnfe){
			logger.error(cnfe.getMessage());
		}catch(SQLException sqle){
			logger.error(sqle.getMessage());
		}
		if(connection == null)
			logger.error("Could not get DB connection, please look into the connection properties.");

		return connection;
	}

	

	// commented temporary main method delete after connection test is done
	/*public static void main(String[] args){

		List<InvoiceDto> data = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sqlQuery = "select * from V_INV_DETAIL_TEST WHERE ROWNUM <=1000 AND INVOICE_NO='0000002538' ORDER BY INVOICE_NO" ;

		if(conn != null){
			data = new ArrayList<InvoiceDto>();
			try{
				System.out.println("before pstmt");
				pstmt = conn.prepareStatement(sqlQuery);
				System.out.println("before rs");
				rs = pstmt.executeQuery();
				while(rs.next()){
					invoiceDto = new InvoiceDto();
					invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));
					invoiceDto.setPaymentStatus(rs.getString("PAID_STATUS"));
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					invoiceDto.setPoNumber(rs.getString("PO_NO"));
					invoiceDto.setVendorGsl(rs.getString("VENDOR_GSL"));
					invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));					
					
					data.add(invoiceDto);
				}
				System.out.println("after while loop complete");
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("data="+data);
	
	}*/

}
