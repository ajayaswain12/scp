package com.ge.scp.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.ge.scp.db.DBConnection;
import com.ge.scp.dto.InvoiceDto;

public class InvoiceUtility {
	
	final static Logger logger = Logger.getLogger(InvoiceUtility.class);
			
	public static List<InvoiceDto> getData(String vendorGsl, String invoiceNumber, String poNumber, Date invoiceDate, double amount){
		List<InvoiceDto> data = null;
		InvoiceDto invoiceDto = null;

		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sqlQuery = "select * from V_INV_DETAIL_TEST WHERE ROWNUM <=1000 ORDER BY INVOICE_NO" ;
		
		String condition_vendorGsl;
		String condition_invoiceNumber;
		String condition_poNumber;
		String condition_invoiceDate;
		String condition_amount;
		

		
		if (null != vendorGsl && "" != vendorGsl) {
			condition_vendorGsl = "VENDOR_GSL="+vendorGsl;
		}
		if (null != invoiceNumber && "" != invoiceNumber) {
			condition_invoiceNumber = "INVOICE_NO="+invoiceNumber;
		}
		if (null != poNumber && "" != poNumber) {
			condition_poNumber = "PO_NO="+poNumber;
		}
		if (null != invoiceDate) {
			condition_invoiceDate = "ACTUAL_INVOICE_DT="+invoiceDate;
		}
		if (0.0 != amount) {
			condition_amount = "INVOICED_AMOUNT_USD="+amount;
		}

		if(conn != null){
			data = new ArrayList<InvoiceDto>();
			try{
				pstmt = conn.prepareStatement(sqlQuery);
				rs = pstmt.executeQuery();
				while(rs.next()){
					invoiceDto = new InvoiceDto();
					invoiceDto.setInvoiceNumber(rs.getString("INVOICE_NO"));
					invoiceDto.setInvoiceDate(rs.getDate("ACTUAL_INVOICE_DT"));
					invoiceDto.setCurrency(rs.getString("INVOICE_CURRENCY_CD"));
					invoiceDto.setAmount(rs.getDouble("INVOICED_AMOUNT_USD"));
					invoiceDto.setOnHold(rs.getString("HOLD_LKP_DESC"));
					invoiceDto.setPaymentStatus(rs.getString("PAID_STATUS"));
					invoiceDto.setDueDate(rs.getDate("PAYMENT_DUE_DT"));
					invoiceDto.setPoNumber(rs.getString("PO_NO"));
					invoiceDto.setVendorGsl(rs.getString("VENDOR_GSL"));
					invoiceDto.setVendorName(rs.getString("VENDOR_NAME"));						
					
					data.add(invoiceDto);
				}				
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		System.out.println("data="+data);
		return data;
	}
}
